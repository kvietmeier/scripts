#!/bin/ksh

osd="alln01-1-csx-ceph1-003 \
alln01-1-csx-ceph1-004 \
alln01-1-csx-ceph1-005 \
alln01-1-csx-ceph1-006 \
alln01-1-csx-ceph1-007 \
alln01-1-csx-ceph1-008 \
alln01-1-csx-ceph1-009 \
alln01-1-csx-ceph1-010 \
alln01-1-csx-ceph1-011 \
alln01-1-csx-ceph1-012 \
alln01-1-csx-ceph1-013 \
alln01-1-csx-ceph1-014 \
alln01-1-csx-ceph1-015 \
alln01-1-csx-ceph1-016 \
alln01-1-csx-ceph1-017 \
alln01-1-csx-ceph1-020 \
alln01-1-csx-ceph1-021 \
alln01-1-csx-ceph1-022 \
alln01-1-csx-ceph1-023 \
alln01-1-csx-ceph1-024 \
alln01-1-csx-ceph1-025 \
alln01-1-csx-ceph1-026 \
alln01-1-csx-ceph1-027 \
alln01-1-csx-ceph1-028 \
alln01-1-csx-ceph1-029 \
alln01-1-csx-ceph1-030 \
alln01-1-csx-ceph1-031 \
alln01-1-csx-ceph1-032 \
alln01-1-csx-ceph1-033 \
alln01-1-csx-ceph1-034 \
alln01-1-csx-ceph1-037 \
alln01-1-csx-ceph1-038 \
alln01-1-csx-ceph1-039 \
alln01-1-csx-ceph1-040 \
alln01-1-csx-ceph1-041 \
alln01-1-csx-ceph1-042 \
alln01-1-csx-ceph1-043 \
alln01-1-csx-ceph1-044 \
alln01-1-csx-ceph1-045 \
alln01-1-csx-ceph1-046 \
alln01-1-csx-ceph1-047 \
alln01-1-csx-ceph1-048 \
alln01-1-csx-ceph1-049 \
alln01-1-csx-ceph1-050 \
alln01-1-csx-ceph1-051 "

user="root"
passwd="rU\$bayP:haiv}"

for h in $osd; do
	echo "$h:"
	./sshid.exp $user $h $passwd
	#ssh $user@$h -x "for i in `ps -ef | grep fio | grep -v grep| awk '{print $2}'`; do sudo kill -9 $i; done"
	ssh $user@$h -x " uname -a"
done
