#!/bin/ksh

conf="20vm"
qd="16"

for i in $conf; do
	./perf.sh $i.conf ; sleep 120
	./depth.sh $i
	tlist=""
	alist=""
	for j in $qd; do
		tlist="$tlist $i/d$j.tot"
		alist="$alist $i/d$j.avg"
	done
	./table.sh $tlist 2>/dev/null | tee $i-tot.txt
	./table.sh $alist 2>/dev/null | tee $i-avg.txt
done

for j in $qd; do
	tlist=""
	alist=""
	file=""
	for i in $conf; do
		tlist="$tlist $i/d$j.tot"
		alist="$alist $i/d$j.avg"
		file="$i-$file"
	done
	./table.sh $tlist 2>/dev/null | tee d$j-tot.txt
	./table.sh $alist 2>/dev/null | tee d$j-avg.txt
done

tlist=""
alist=""
file=""
for i in $conf; do
for j in $qd; do
	tlist="$tlist $i/d$j.tot"
	alist="$alist $i/d$j.avg"
	file="$i-$file"
done
done
./table.sh $tlist 2>/dev/null | tee total.txt
./table.sh $alist 2>/dev/null | tee average.txt
