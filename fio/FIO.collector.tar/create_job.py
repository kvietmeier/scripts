#!/usr/bin/python
################################
## AUTHOR: Mike Duarte ##
## COMPANY: CISCO SYSTEMS ##
## E-MAIL: mikduart@cisco.com ##
## PHONE: 408-894-7826 ##
################################

#Importing Modules
import sys

filename = sys.argv[1]
bs = sys.argv[2]
numjobs = sys.argv[3]
datatesttype = sys.argv[4]
runtime = sys.argv[5]
size = sys.argv[6]
iodepth = sys.argv[7]
filename = sys.argv[8]
directory = sys.argv[9]
target = open(filename, 'w')


 
# Create jobfile entries
line1 = "[global]\n"
line2 = "description=libaio engine {0} blocks (Direct I/O) {1}\n".format(bs, datatesttype)
line3 = "\n"
line4 = "[libaio-direct-{0}-{1}]\n".format(bs, datatesttype)
line5 = "bs={0}\n".format(bs)
line6 = "rw={0}\n".format(datatesttype)
line7 = "rwmixread=80\n"
line8 = "direct=1\n"
line9 = "buffered=0\n"
line10 = "size={0}\n".format(size)
line11 = "ioengine=libaio\n"
line12 = "iodepth={0}\n".format(iodepth)
line13 = "filename={0}\n".format(filename)
line14 = "directory={0}\n".format(directory)
line15 = "runtime={0}\n".format(runtime)
line16 = "randrepeat=0\n"
line17 = "numjobs={0}\n".format(numjobs)

 
# Create the Jobfile
target.write(line1)
target.write(line2)
target.write(line3)
target.write(line4)
target.write(line5)
target.write(line6)
 
if datatesttype == "randreadwrite" or 'readwrite':
  target.write(line7)

target.write(line8)
target.write(line9)
target.write(line10)
target.write(line11)
target.write(line12)
target.write(line13)
target.write(line14)

if runtime != '0':
  target.write(line15)

target.write(line16)
target.write(line17)

target.close()
