#!/bin/ksh

set -A vm
set -A vol
dev="vdb" # vdc vdd vde vdf vdg vdh vdi"

typeset -i i=0
typeset -i v=0

nova list | egrep "fio-driver" | grep -i "running" | awk '{print $2}' | \
while read lin
do
	vm[$i]=$lin
	((i+=1))
done

nova volume-list | grep "fio-vdb" |grep -i "in-use" |  awk '{print $2}' | \
while read lin
do
	vol[$v]=$lin
	((v+=1))
done


((i-=1))
((v-=1))
while [ $i -ge 0 ]; do
	for d in $dev; do
		echo "nova volume-attach ${vm[$i]} ${vol[$v]} /dev/$d "
		#nova volume-attach ${vm[$i]} ${vol[$v]} /dev/$d 
		echo "nova volume-detach  ${vm[$i]} ${vol[$v]}"
		nova volume-detach ${vm[$i]} ${vol[$v]}
		((v-=1))
	done
	((i-=1))
done


