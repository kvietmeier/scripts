#!/bin/ksh

if [ $# -ne 1 ]; then
	echo "usage: $0 <dir name>"
	exit
fi

# load config file
dir=$1
conf="$dir.conf"

if [ ! -e $conf ]; then
	echo "Configuration file $conf does not exit"
	exit
fi
source ./$conf

for depth in $iodepth; do
   printf "\n\n$dir: iodepth=$depth\n\n" 
   for s in $ratio; do
	printf "---------------------------------- r$s-start  ----------------------------------\n" 
	printf "%-12s%-12s%-12s%-12s%-12s%-12s%-12s\n" "bs" "rbw(KB/s)" "riops" "rlat" "wbw(KB/s)" "wiop" "lat(ms)" 

	for b in $blk; do
		#compute data per vm, then take sum or average

		typeset -i trlat=0
		typeset -i twlat=0
		typeset -i trbw=0
		typeset -i twbw=0
		typeset -i triops=0
		typeset -i twiops=0
		typeset -i num=0

		#calc # of files per the block size
		fio=$(ls $dir/d$depth/r$s/$b/*-$b-*.fio)
		num=$(echo $fio | wc -w)
		for file in $fio; do

			if [ ! -f $file ] ; then
				echo "file: $file does not exist"
				continue	
			fi

			typeset -i rlat=0
			typeset -i wlat=0
			typeset -i rbw=0
			typeset -i wbw=0
			typeset -i riops=0
			typeset -i wiops=0

			let "rbw=$(cat $file | grep "read" | grep "iops" | sed 's/^.*bw=//g' | sed 's/,.*//g' |sed 's/[MBK].*//g' | sed 's/ //g')"
			kb=$(cat $file | grep "read" | grep "iops" | sed 's/^.*bw=//g' | sed 's/,.*//g' | sed 's/[0-9.]//g' | sed 's/\/.*//g'|sed 's/ //g')
			if [ "$kb" == "B" ] ; then
				let "rbw=rbw/1000"
			fi
			if [ "$kb" == "MB" ] ; then
				let "rbw=rbw*1000"
			fi
			let "trbw=trbw+rbw"
				 
			let "riops=$(cat $file | grep "read" | grep "iops" |sed 's/^.*iops=//g' | sed 's/,.*//g')"
			let "triops=triops+riops"

			let "rlat=$(cat $file | sed '/write:/,$d' | grep "lat" | grep "avg" | egrep -v "slat|clat" | sed 's/^.*avg=//g' | sed 's/,.*//g')"
			rsec=$(cat $file | sed '/write:/,$d' | grep "lat" | grep "avg" | egrep -v "slat|clat" | sed 's/^.*(//g' | sed 's/).*//g')
			if [ "$rsec" == "usec" ] ; then
				let "rlat=rlat/1000"
			fi
			let "trlat=trlat+rlat"
			
			let "wbw=$(cat $file | grep "write" | grep "iops" | sed 's/^.*bw=//g' | sed 's/,.*//g' |sed 's/[MBK].*//g' | sed 's/ //g')"
			kb=$(cat $file | grep "write" | grep "iops" | sed 's/^.*bw=//g' | sed 's/,.*//g' | sed 's/[0-9.]//g' | sed 's/\/.*//g'|sed 's/ //g')
			if [ "$kb" == "B" ] ; then
				let "wbw=wbw/1000"
			fi
			if [ "$kb" == "MB" ] ; then
				let "wbw=wbw*1000"
			fi
			let "twbw=twbw+wbw"
				 
			let "wiops=$(cat $file | grep "write" | grep "iops" | sed 's/^.*iops=//g' | sed 's/,.*//g')"
			let "twiops=twiops+wiops"

			let "wlat=$(cat $file | sed '1,/write:/d' | grep "lat" | grep "avg" | egrep -v "slat|clat" | sed 's/^.*avg=//g' | sed 's/,.*//g')"
			wsec=$(cat $file | sed '1,/write:/d' | grep "lat" | grep "avg" | egrep -v "slat|clat" | sed 's/^.*(//g' | sed 's/).*//g')
			if [ "$wsec" == "usec" ] ; then
				let "wlat=wlat/1000"
			fi
			let "twlat=twlat+wlat"
	
			#((num+=1))		
			#printf "%-12s%-12s%-12s%-12s%-12s%-12s%-12s\n" "$b" "$rbw" "$riops"  "$rlat" "$wbw" "$wiops" "$wlat" 
		done # end of file loop
		
		let "trlat=trlat/num"
		let "twlat=twlat/num"
		printf "%-12s%-12s%-12s%-12s%-12s%-12s%-12s\n" "$b" "$trbw" "$triops"  "$trlat" "$twbw" "$twiops" "$twlat" 
	done
	printf "---------------------------------- r$s-end ----------------------------------\n\n" 
   done # end rw ratio
done # enf of iodepth

