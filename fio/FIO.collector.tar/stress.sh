#!/bin/ksh

./perf.sh cache.conf ; sleep 120
./parse.sh cache | tee cache.txt
./perf.sh nocache.conf ; sleep 120
./parse.sh nocache | tee nocache.txt

#./perf.sh 1vm.conf ; sleep 60
#./perf.sh 2vm.conf ; sleep 60
#./perf.sh 4vm.conf ; sleep 60
#./perf.sh 10vm.conf ; sleep 60
#./perf.sh 20vm.conf ; sleep 60
#./perf.sh 40vm.conf ; sleep 60
#./perf.sh 80vm.conf ; sleep 60
#./perf.sh 120vm.conf ; sleep 60
