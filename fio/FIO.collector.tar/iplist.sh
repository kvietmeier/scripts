nova list | grep fio-driver | awk '{print $12}' | sed 's/^pub.*=//g' | sed 's/$/ \\/'
