

nova list | grep driver | awk '{print $12}' | sed 's/^public.*=//' | sed 's/$/ \\/'

