#!/bin/bash

# Partition (0 offset) the RBD with 1 partition
sudo parted -s /dev/vdb mklabel mbr
sudo fdisk /dev/vdb <<EOF
n
p



w
EOF

# Format the RBD with ext4
sudo  mkfs.ext4 /dev/vdb1

# Mount the new partition
sudo mkdir /mnt
sudo mount /dev/vdb1 /mnt
