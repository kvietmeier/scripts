#!/bin/ksh

if [ $# -ne 1 ]; then
        echo "usage: $0 <conf file name>"
        exit
fi

conf_file=$1
conf_name=`echo $1 | sed 's/\.conf//'`

if [ ! -e $conf_file ]; then
        echo "Configuration file $conf does not exit"
        exit 2
fi 

./perf.sh $conf_file
