#!/bin/ksh

#alln01-1-csx-nova2-011"
vms="\
10.114.195.60 \
"

user="ubuntu"
passwd="ubuntu"

for h in $vms; do
	echo $h
	./sshid.exp $user $h $passwd &
	#ssh $user@$h -x "sudo apt-get --yes install fio ksh sysstat" & 
	#ssh $user@$h -x "sudo apt-get --yes install sysstat" & 
	ssh $user@$h -x "fio --version"
	#scp partition.sh $user@$h:~/
	#ssh $user@$h -x "chmod a+x ~/partition.sh; ~/partition.sh"
	#ssh $user@$h -x "sudo apt-get --yes purge fio; sudo ln -s $HOME/fio-2.1.7/fio /usr/bin/fio"
	#ssh $user@$h -x "uname -a"
	ssh $user@$h -x "lsblk"
done
