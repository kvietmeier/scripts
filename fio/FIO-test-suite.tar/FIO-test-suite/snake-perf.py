#!/bin/python

import os,sys,string
import ConfigParser
import commands
from optparse import OptionParser
from datetime import datetime
import subprocess
import time
# This script take input file which defines the following information
# run=<name of the run>
# blk="<block size> 1k 2k 4k 8k 16k 32k 64k 128k 256k 512k 1m 2m 4m"
# ratio=<rear/write ratio>, "0 20 50 80 100"
# osd=<list of osd>
# vms<list of VM IP>

# usage

def options_usage() :
        parser = OptionParser(usage="\n%prog -c <conf file>",version="%prog 1.0")
        parser.add_option("-c","--config-file",dest="conf_file",help="Config file -- INI style configuration file for FIO execution.")
        (options,args) = parser.parse_args()
        result = options
        return result

def loadConf(conf_file) :
	# loadConf - reads and loads the FIO configuration file
        fio_config = ConfigParser.RawConfigParser()
        fio_config.read(conf_file)
        flavor_list = fio_config.sections()
	# fio run name - uses the name of the conf file without ".conf" and timestamp of the run (to the seconds)
	now = (datetime.now()).strftime("%Y%m%d")
	# remove the pathname from the user input if any
	file_name_only = os.path.basename(conf_file)
	project = file_name_only.strip(".conf")
        #print flavor_list
        #unpack settings
	fio_launch_data = {}
        for flav in flavor_list :
		# single params
		job = fio_config.get(flav,'job')
		user = fio_config.get(flav,'user')
		engine = fio_config.get(flav,'engine')
		num_run = fio_config.get(flav,'num_run')
		rwmixread = fio_config.get(flav,'rwmixread')
		size = fio_config.get(flav,'size')
		dev = fio_config.get(flav,'dev')
		runtime = fio_config.get(flav,'runtime')
		# multiple params
		blk_size = fio_config.get(flav,'blk')
		rw_mix = fio_config.get(flav,'ratio')
		depth = fio_config.get(flav,'iodepth')
		vms = fio_config.get(flav,'vms')
		fio_launch_data[flav] = {'dev':dev,'size':size,'rwmixread':rwmixread,'engine':engine,
					'num_run':num_run,'runtime':runtime,'job':job,'user':user,'blk_size':blk_size.split(','),
					'rw_mix':rw_mix.split(','),'depth':depth.split(','),'vms':vms.split(',')}
	return (project,fio_launch_data)
	
def fioCommand(dev,size,blk_size,job,runtime,depth,rw_mix,rwmixread,engine,flavor,project,num_run,ip) :
	# generates the actual FIO command that will be executed on each VM
	# output file name on fio controller
	output_file = "%s-f%s-d%s-r%s-%s-n%s-%s.fio" % (project,flavor,depth,rw_mix,blk_size,num_run,ip)
	# output path on fio controller
	output_path="%s/f%s/d%s/r%s/%s" % (project,flavor,depth,rw_mix,blk_size)
	# fio-command
	command = ("fio --filename=%s --size=%s --bs=%s --numjobs=%s --runtime=%s --iodepth=%s --direct=1 --rw=%s "
		"--rwmixread=%s  --ioengine=%s --group_reporting --name=%s"
		% (dev,size,blk_size,job,runtime,depth,rw_mix,rwmixread,engine,output_file))

	

	return (output_file,output_path,command)

def run_command(command):
    p = subprocess.Popen(command,
                         stdout=subprocess.PIPE,
                         stderr=subprocess.STDOUT)
    return iter(p.stdout.readline, b'')

def fioExecute(output_file,output_path,command,ip,user) :
	
	# executes a single fio command for a given IP 
	#create output_path if it doesnt exist
	if not os.path.exists(output_path):
    		os.makedirs(output_path)
	#print subprocess.Popen('ssh %s@%s -x "sudo %s" | sudo tee -a %s/%s &' % (user,ip,command,output_path,output_file),shell=True)
	print subprocess.Popen('ssh %s@%s -x " %s" |  tee -a %s/%s &' % (user,ip,command,output_path,output_file),shell=True)
	#print subprocess.Popen('ssh cloud-user@%s -x "sudo uptime" | sudo tee -a %s/%s ' % (ip,output_path,output_file), shell=True )


if __name__ == "__main__" :

        user_input = options_usage()
        conf_file = user_input.conf_file
        #print conf_file
        if conf_file and os.path.exists(conf_file) :
          project,launch_data =  loadConf(conf_file)
	  # for loops ...
	  for flavor in launch_data :
	    config = launch_data[flavor]
	    num_run = int(config["num_run"]) + 1
	    dev = config['dev']
	    size = config['size']
   	    job = config['job']
	    runtime = config['runtime']
	    rwmixread = config['rwmixread']
	    engine = config['engine']
	    user = config['user']
	    for depth in config["depth"] :
	      for ratio in config["rw_mix"] :
		for blk_size in config["blk_size"] :
		  for n in range(1,num_run) :
		    for ip in config["vms"] :
		      output_file,output_path,command = fioCommand(dev,size,blk_size,job,runtime,depth,ratio,rwmixread,engine,flavor,project,n,ip)
		      fioExecute(output_file,output_path,command,ip,user)
		    print "\t===================done=================="
		    time.sleep(int(runtime))
		    time.sleep(90)
		    for i in [1,2,3,4,5] :
		    	clean_command = "for p in `ps -ef | grep ssh | grep 'sudo fio'  | awk '{print $2}' `; do kill -9 $p;done"
		    	commands.getoutput(clean_command)
		    #print flavor,"::::",output_path,"::::",output_file
		    #print command
		    #print 100*"::"	
        else :
                print "%s : There is no such file." % conf_file
                sys.exit(251)
