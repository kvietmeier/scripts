#!/bin/python

import numpy as np 
import matplotlib as mpl
mpl.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.backends.backend_pdf import PdfPages
 
 
x = np.linspace(10,100)
y = np.sin(x)

x = [1,2,3,4,5]
y = [104161,104914,104106,104225,101908]
z = [176069,142792,214983,348277,407350]
a = [43808,35259,53822,87936,102981]
#plt.plot(x,y)
#print dir(plt)

index = np.arange(len(x))
bar_width = 0.2

opacity = 0.4
error_config = {'ecolor': '0.3'}

rects1 = plt.bar(index, y, bar_width,
                 alpha=opacity,
                 color='g',
                 yerr=x,
                 error_kw=error_config,
                 label='16k')

rects2 = plt.bar(index + bar_width, z, bar_width,
                 alpha=opacity,
                 color='y',
                 yerr=x,
                 error_kw=error_config,
                 label='8k')

rects3 = plt.bar(index + bar_width + bar_width, a, bar_width,
                 alpha=opacity,
                 color='r',
                 yerr=x,
                 error_kw=error_config,
                 label='32k')

plt.xlabel('Operation')
plt.ylabel('IOPs')
plt.title('IOPs for different Operation')
plt.xticks(index + bar_width, ('R', 'RW', 'RANDR', 'RANDWR', 'RANDRWR'))
plt.legend()

plt.tight_layout()
#plt.show()



#with plt.style.context('fivethirtyeight'):
#    plt.plot(x,y)
#    plt.plot(x,z)
#    plt.plot(x,a)


#plt.xlabel("Time")
#plt.ylabel("IOPs")
plt.savefig("foo2.pdf")

