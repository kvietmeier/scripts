#!/usr/bin/python

import os,sys,string
import ConfigParser
import commands
from optparse import OptionParser
from datetime import datetime
import subprocess
import time
import getpass

# usage

def options_usage() :
        parser = OptionParser(usage="\n%prog -i <vm spinup conf file> -v <volume conf file>",version="%prog 1.0")
        parser.add_option("-i","--instance-config-file",dest="vm_conf_file",help="Config file -- INI style configuration file for VM spinup")
        parser.add_option("-v","--volume-config-file",dest="vol_conf_file",help="Config file -- INI style configuration file for Volume creation and attachment")
        parser.add_option("-r","--openstack-rc-file",dest="rc_file",help="RC file -- openstack RC file")
        parser.add_option("-c","--cloud-init-file",dest="cloud_init_file",help="Cloud init file -- cloud init file")
        (options,args) = parser.parse_args()
        result = options
        return result

def setEnvironment(rc_file):
        # get rc_file,image,flavor,networks,sshkey,cloud-init
        #
        #rc_file = raw_input("OpenStack RC file: ")
        if os.path.isfile(rc_file) :
                os_password = getpass.getpass("Please enter your OpenStack Password: ")
                rc_vars = commands.getoutput("cat %s | egrep -v '#|^$|echo|read|OS_PASSWORD'" % rc_file)
                env_params = rc_vars.split('\n')
                env_params.append("export OS_PASSWORD=%s" % os_password )
                #print env_params
                # export env values
                for p in env_params :
                        pstring = p.strip('export ')
                        key_val = pstring.split("=")
                        key = key_val[0]
                        val1 = key_val[1]
                        val = val1.strip('"')
                        #print "%s : %s" % (key,val)
                        os.environ[key] = val
                #print commands.getoutput("env | grep OS_")
                # test env setting are ok
                print "Testing openstack environment setting ... "
                status,output = commands.getstatusoutput("nova list")
                #print "status:",status
                #print "output:",output
                if status != 0 :
                        print "Openstack CLI environment setting not correct"
                        print output
                        sys.exit(251)
                else :
                        print "\nEnvironment settings look ok ! proceeding ..."
        else :
                print "%s : No such file" % rc_file
                sys.exit(251)
	
	status,output = commands.getstatusoutput("nova keypair-list | grep -w FIO-CONTROLLER-KEY")
	if status != 0 :
		add_keypair = "nova keypair-add --pub-key /root/.ssh/id_rsa.pub FIO-CONTROLLER-KEY"
		status,output = commands.getstatusoutput(add_keypair)
		if status != 0 :
			print "%s command failed, please check " % add_keypair
			sys.exit(251)
# configuration parsing

def loadConf(vm_conf_file,vol_conf_file) :

        # vm_config - reads and loads the vm/instance FIO configuration file
        vm_config = ConfigParser.RawConfigParser()
        vm_config.read(vm_conf_file)
        flavor_list = vm_config.sections()

        # fio run name - uses the name of the conf file without ".conf" and timestamp of the run (to the seconds)
        now = (datetime.now()).strftime("%Y%m%d")

        fio_spinup_data = {}
        for flav in flavor_list :
                # single params
                project_name = vm_config.get(flav,'project_name')
                number_of_clients = vm_config.get(flav,'number_of_clients')
                flavor_id = vm_config.get(flav,'flavor_id')
                subnet_id = vm_config.get(flav,'subnet_id')
		image_id = vm_config.get(flav,'image_id')
                fio_spinup_data[flav] = {'project_name':project_name,'number_of_clients':number_of_clients,'flavor_id':flavor_id,'subnet_id':subnet_id,'image_id':image_id}

	# vol_config - reads and loads the volume FIO configuration file
        vol_config = ConfigParser.RawConfigParser()
        vol_config.read(vol_conf_file)
        volume_list = vol_config.sections()
	fio_volattach_data = {}
	for vol in volume_list :
		project_name = vol_config.get(vol,'project_name')
		volume_device_name = vol_config.get(vol,'volume_device_name')
		volume_type = vol_config.get(vol,'volume_type')
		volume_size = vol_config.get(vol,'volume_size')
		mount_point = vol_config.get(vol,'mount_point')
		fio_volattach_data[vol] = {'volume_device_name':volume_device_name,'volume_type':volume_type,'volume_size':volume_size,'mount_point' : mount_point}
		

		
        return (fio_spinup_data,fio_volattach_data)

def rigBuild(fio_spinup_data,fio_volattach_data,cloud_init_file) :
	for flav in fio_spinup_data.keys() :
		project_name = fio_spinup_data[flav]['project_name']
                number_of_clients = fio_spinup_data[flav]['number_of_clients']
                flavor_id = fio_spinup_data[flav]['flavor_id']
                subnet_id = fio_spinup_data[flav]['subnet_id']
                image_id = fio_spinup_data[flav]['image_id']
		for i in range(1,int(number_of_clients)+1) :
			spinup_command = "nova boot  --flavor %s --nic net-id=%s --image %s --user-data %s --key-name FIO-CONTROLLER-KEY fio-driver-%s-%s-%s " % (flavor_id,subnet_id,image_id,cloud_init_file,project_name,flav,i)
			#
			print "booting fio-driver-%s-%s-%s" % (project_name,flav,i)
			print "progress : %s %%" % ((float(i) / float(number_of_clients))*100.0 )
			print commands.getoutput(spinup_command)
			time.sleep(2)
			os.system("clear")
		#for i in range(1,int(number_of_clients)+1) :
		#	for vol in fio_volattach_data.keys() :
		#		project_name = vol_config.get(vol,'project_name')
                #		volume_device_name = vol_config.get(vol,'volume_device_name')
                #		volume_type = vol_config.get(vol,'volume_type')
                #		volume_size = vol_config.get(vol,'volume_size')
                #		mount_point = vol_config.get(vol,'mount_point')
		#		volume_name = "fio-vol-%s-%s-%s-%s" % (project_name,flav,volume_type,i)
		#		volume_create_command = "cinder create --display-name %s --volume-type %s %s" % (volume_name,volume_type,volume_size)
		#		#
		
if __name__ == "__main__" :
	user_input = options_usage()
	
	rc_file = user_input.rc_file
	cloud_init_file = user_input.cloud_init_file
	vm_conf_file = user_input.vm_conf_file
	vol_conf_file = user_input.vol_conf_file

	setEnvironment(rc_file)		
	
	fio_spinup_data,fio_volattach_data = loadConf(vm_conf_file,vol_conf_file)
	rigBuild(fio_spinup_data,fio_volattach_data,cloud_init_file)
