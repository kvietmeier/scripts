#!/bin/python
import os,sys,string
import ConfigParser
import commands
from optparse import OptionParser
import subprocess
import re
import time
import matplotlib as mpl
mpl.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.backends.backend_pdf import PdfPages
from pylab import *
from snake_parse import loadConf
from snake_parse import fioTimeSeries

date_string = time.strftime("%d_%m_%Y")

def options_usage() :
        parser = OptionParser(usage="\n%prog -c <conf file> -d <comma separated list of metrics>",version="%prog 1.0")
        parser.add_option("-c","--config-file",dest="conf_file",help="Config file -- INI style configuration file used for FIO execution.")
	parser.add_option("-d","--data",dest="data",help="data -- for generating charts, here are the possible data names:\n"
			  "trbw = total read BW, \n"
			  "triops = total read IOps, \n"
			  "arlat = average read latency in ms, \n"
			  "twbw = total write BW\, n"
			  "twiops = total write IOps, \n"
			  "awlat = average write latency in ms, \n"
			  "arbw = average read BW\, n"
			  "ariops = average read IOPs, \n"
			  "awbw = average write BW, \n"
			  "awiops = average write IOps, \n")
        (options,args) = parser.parse_args()
        result = options
        return result

def snakeChart() :
	# units dictionary
	units_dict = {"trbw" : "Read BW(KB/s)", "triops" : "Read IOps" , "arlat" : "Average Read Lat(ms)", "twbw":"Write BW(KB/s)", "twiops" : "Write IOps", "awlat":"Average Write Lat(ms)", "arbw" : "Average Read BW(KB/s)", "ariops":"Average Read IOps", "awbw":"Average Write BW(KB/s)", "awiops":"Average Write IOps"}
	user_input = options_usage()
        conf_file = user_input.conf_file
	data = user_input.data
	if data :
        	metrics = data.split(",")
	else :
		print ("You need to provide comma separated list of metrics for charting\n"
		      "These are the possible values available :\n"
		      "trbw = total read BW, \n"
                      "triops = total read IOps, \n"
                      "arlat = average read latency in ms, \n"
                      "twbw = total write BW, \n"
                      "twiops = total write IOps, \n"
                      "awlat = average write latency in ms, \n"
                      "arbw = average read BW, \n"
                      "ariops = average read IOPs, \n"
                      "awbw = average write BW, \n"
                      "awiops = average write IOps, \n")
		sys.exit(251)

	for x in metrics :
		if x not in units_dict.keys() :
			print "%s - is NOT a valid metrics name\n" % x
			print "Run ./snake_chart.py --help to see the complete list\n"
			sys.exit(251)

	number_of_graphs = 0
	aggregate_data = []
	graph_data = []
        if conf_file and os.path.exists(conf_file) :
                project,fio_launch_data = loadConf(conf_file)
                chart_input = fioTimeSeries(project,fio_launch_data)
		flavor_list = fio_launch_data.keys()
		for flavor in flavor_list :
			conf = fio_launch_data[flavor] 
			# charting per  (flavor,depth,ratio,block_size) combo
			depth = conf["depth"]
			ratio = conf["rw_mix"]
			block_size = conf["blk_size"]
			#print depth,ratio,block_size,flavor,metrics
			for d in depth :
				for r in ratio :
					for bs in block_size :
						for m in metrics :
							# the above list makes up a chart name	
							chart_name = "%s-%s-%s-%s : %s" % (flavor,d,r,bs,m)
							#print chart_name
							# get chart data 
							x_axis = []
							y_axis = []
							for data in chart_input :
								 if ( data["flavor"] == flavor and data["depth"] == d and data["ratio"] == r and data["block_size"] == bs) :
									x_axis.append(data["run"])
									y_axis.append(data[m])
							y_label = units_dict[m]
							x_label = "run"
							#print "*"*100
							number_of_graphs += 1
							graph_data.append({"chart_name":chart_name,"y_label":y_label,"x_label":x_label,"y_data":y_axis,"x_data":x_axis})
							aggregate_data.append({"flavor" : flavor,"depth": d, "ratio" : r,"block_size" : bs, "chart_data" : {"metrics":m,"y_label":y_label,"x_label":x_label,"y_data":y_axis,"x_data":x_axis}})
	if ( number_of_graphs % 2 ) != 0 :
		rows = ( number_of_graphs + 1 ) / 2
	else : 
		rows = number_of_graphs / 2

	if number_of_graphs > 1 :
		columns = 2
	else :
		columns = 1

	# figure_size = 10inch/column*columns , 5inch/row*rows
	figure_width = 10 * columns
	figure_height = 5 * rows


	#subplot = rows,columns,fig_num
	# start with row 1 fig 1
	print "Generating charts ..."
	row_id = 1
	fig_id = 1
	fig = plt.figure()
	title_font = {'fontname':'Arial', 'size':'16', 'color':'black', 'weight':'normal','verticalalignment':'bottom'} # Bottom vertical alignment for more space
        axis_font = {'fontname':'Arial', 'size':'14'}
	for g in graph_data :
		title = g["chart_name"]
		x_label = g["x_label"]
		y_label = g["y_label"]
		x_data = g["x_data"]
		y_data = g["y_data"]
		draw = fig.add_subplot(int(rows),int(columns),int(fig_id))
		draw.bar(x_data, y_data,width=0.5,color='g',align='center')
		draw.set_xlabel(x_label,**axis_font)
		draw.set_ylabel(y_label,**axis_font)
		draw.set_title(title,**title_font)
		fig_id +=1
	

	fig.set_size_inches(figure_width,figure_height)
	output_file = "%s_%s_charts.pdf" % (date_string,conf_file.strip(".conf"))
	print "Output file : %s\n\n" % output_file
	plt.savefig(output_file)
	return aggregate_data



if __name__ == "__main__" :
	snakeChart()

