#!/bin/python

import os,sys,string
import ConfigParser
import commands
from optparse import OptionParser
from datetime import datetime
import subprocess
import time
import re
from prettytable import PrettyTable

# usage

def options_usage() :
        parser = OptionParser(usage="\n%prog -c <conf file>",version="%prog 1.0")
        parser.add_option("-c","--config-file",dest="conf_file",help="Config file -- INI style configuration file used for FIO execution.")
        (options,args) = parser.parse_args()
        result = options
        return result

def loadConf(conf_file) :
	# loadConf - reads and loads the FIO configuration file
        fio_config = ConfigParser.RawConfigParser()
        fio_config.read(conf_file)
        flavor_list = fio_config.sections()
	# fio run name - uses the name of the conf file without ".conf" and timestamp of the run (to the seconds)
	now = (datetime.now()).strftime("%Y%m%d")
	# remove the pathname from the user input if any
	file_name_only = os.path.basename(conf_file)
	project = file_name_only.strip(".conf")
        #print flavor_list
        #unpack settings
	fio_launch_data = {}
        for flav in flavor_list :
		# single params
		job = fio_config.get(flav,'job')
		user = fio_config.get(flav,'user')
		engine = fio_config.get(flav,'engine')
		num_run = fio_config.get(flav,'num_run')
		rwmixread = fio_config.get(flav,'rwmixread')
		size = fio_config.get(flav,'size')
		dev = fio_config.get(flav,'dev')
		runtime = fio_config.get(flav,'runtime')
		# multiple params
		blk_size = fio_config.get(flav,'blk')
		rw_mix = fio_config.get(flav,'ratio')
		depth = fio_config.get(flav,'iodepth')
		vms = fio_config.get(flav,'vms')
		fio_launch_data[flav] = {'dev':dev,'size':size,'rwmixread':rwmixread,'engine':engine,
					'num_run':num_run,'runtime':runtime,'job':job,'user':user,'blk_size':blk_size.split(','),
					'rw_mix':rw_mix.split(','),'depth':depth.split(','),'vms':vms.split(',')}
	return (project,fio_launch_data)
	
def fioTimeSeries(project,fio_launch_data) :
	# dev,size,blk_size,job,runtime,depth,rw_mix,rwmixread,engine,flavor,project,num_run,ip
	
	# list of flavors for which data is collected
	flavor_list = fio_launch_data.keys()
	# for each flavor collecte time series data 
	for flavor in flavor_list :
		flavor_params = fio_launch_data[flavor]
		depth = flavor_params['depth']
		rw_mix = flavor_params['rw_mix']
		blk_size = flavor_params['blk_size']
		num_run = int(flavor_params['num_run']) + 1
		vms = flavor_params['vms']
		# output path on fio controller
		for d in depth :
			for ratio in rw_mix :
		   		for bs in blk_size :
					print ("=====================================================================================================================\n"
                                               "Flavor : %s \n"
                                               "Queue Depth : %s \n"
                                               "Ratio(opration) : %s\n" % (flavor,d,ratio))
                                	x = PrettyTable(["Run", "Block Size", "Read BW(KB/s)","Read IOps","Read Latency(ms)","Write BW(KB/s)","Write IOps","Write Latency(ms)"])
					x.padding_width = 1
					# output path on fio controller
                			output_path="%s/f%s/d%s/r%s/%s" % (project,flavor,d,ratio,bs)
					for n in range(1,num_run):
						fio_count = 0
						fio_files = []
						for ip in vms :
							output_file = "%s-f%s-d%s-r%s-%s-n%s-%s.fio" % (project,flavor,d,ratio,bs,n,ip)
							full_path = output_path + '/' + output_file
							if os.path.exists(full_path) :
								fio_count += 1
								fio_files.append(full_path)
						trlat = 0.0
						twlat = 0.0
						trbw = 0.0
						twbw = 0.0
						triops = 0.0
						twiops = 0.0
						num = 0.0
						good_file = False
						for f in fio_files :
							#print f
							rlat = 0.0
							wlat = 0.0
							rbw = 0.0
							wbw = 0.0
							riops = 0
							wiops = 0 
							with open(f) as han :
								read_pattern = re.compile('read : io=.{1,}')
								rbw_pattern = re.compile('bw=\S{1,}/s')
								kb_pattern = re.compile('[a-zA-Z]{1,2}/s')
								read_iops_pattern = re.compile('iops=\d{1,}')
								write_pattern = re.compile('write.{1,}io=.{1,}')
								wbw_pattern = re.compile('bw=\S{1,}/s')
								write_iops_pattern = re.compile('iops=\d{1,}')
								read_section = 0
                                                        	write_section = 0
								for line in han :
								    try :
									read_bingo = read_pattern.search(line)
									if read_bingo :	
										read_section = 1
										read_line = read_bingo.group()
										#print read_line
										rbw_string = rbw_pattern.search(read_line).group()
										kb = kb_pattern.search(rbw_string).group()
										rbw += float(rbw_string.strip(kb).strip('bw='))
										riops_string = read_iops_pattern.search(read_line).group()
										riops = int(riops_string.strip("iops="))
										if kb == "B/s" :
											rbw = rbw/1000
										if kb == "MB/s" :
											rbw = rbw*1000
										trbw += rbw
										triops = triops + riops	
									if read_section == 1 and write_section == 0 :
										#print "read section"
										lat_pattern = re.compile('\s{1,}lat.{1,}')
										read_lat_bingo = lat_pattern.search(line)
										if read_lat_bingo :
											read_lat_string = read_lat_bingo.group()
											#print read_lat_string
											rlat_raw = re.search('avg=\S{1,}',read_lat_string).group()
											rlat = float(rlat_raw.strip('avg=').strip(','))
											rsec_raw = re.search('\([a-zA-Z]{1,}\)',read_lat_string).group()
											rsec = rsec_raw.strip('(').strip(')')
											#print rsec,rlat
											if rsec == "usec" :
												rlat = rlat/1000
											trlat = trlat + rlat
											#print "\n\n"
											read_section = 0
									
										
									write_bingo = write_pattern.search(line)
                                                                        if write_bingo :
                                                                                write_section = 1
                                                                                write_line = write_bingo.group()
                                                                                #print write_line
                                                                                wbw_string = wbw_pattern.search(write_line).group()
                                                                                kb = kb_pattern.search(wbw_string).group()
                                                                                wbw += float(wbw_string.strip(kb).strip('bw='))
                                                                                wiops_string = write_iops_pattern.search(write_line).group()
                                                                                wiops = int(wiops_string.strip("iops="))
                                                                                if kb == "B/s" :
                                                                                        wbw = wbw/1000
                                                                                if kb == "MB/s" :
                                                                                        wbw = wbw*1000
                                                                                twbw += wbw
                                                                                twiops = twiops + wiops
                                                                        if read_section == 0 and write_section == 1 :
                                                                                #print "write section"
                                                                                lat_pattern = re.compile('\s{1,}lat.{1,}avg=.{1,}')
                                                                                write_lat_bingo = lat_pattern.search(line)
                                                                                if write_lat_bingo :
                                                                                        write_lat_string = write_lat_bingo.group()
                                                                                        #print write_lat_string
                                                                                        wlat_raw = re.search('avg=\S{1,}',write_lat_string).group()
                                                                                        wlat = float(wlat_raw.strip('avg=').strip(','))
                                                                                        wsec_raw = re.search('\([a-zA-Z]{1,}\)',write_lat_string).group()
                                                                                        wsec = wsec_raw.strip('(').strip(')')
                                                                                        #print wsec,wlat
                                                                                        if wsec == "usec" :
                                                                                                wlat = wlat/1000
                                                                                        twlat = twlat + wlat
                                                                                        #print "\n\n"
											write_section = 0
									good_file = True	
                                                                    except :  
								    	good_file = False        
						if good_file :
								fio_count += 1
						#print "%s : %s : %s : %s : %s : %s : %s : %s " % (n,bs,trbw,triops,trlat,twbw,twiops,twlat)
						#print fio_count
						#get average of trlat and twlat
						trlat = trlat / fio_count
						twlat = twlat / fio_count
						x.add_row([n,bs,trbw,triops,trlat,twbw,twiops,twlat])
					print x
					print "\n\n"
										


if __name__ == "__main__" :

        user_input = options_usage()
        conf_file = user_input.conf_file
        #print conf_file
        if conf_file and os.path.exists(conf_file) :
		project,fio_launch_data = loadConf(conf_file)
		fioTimeSeries(project,fio_launch_data)
