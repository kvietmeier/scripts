#!/bin/python

import os,sys,string
import getpass,commands

def setEnvironment():
	# get rc_file,image,flavor,networks,sshkey,cloud-init
	#  
	rc_file = raw_input("OpenStack RC file: ")
	if os.path.isfile(rc_file) :
		os_password = getpass.getpass("Please enter your OpenStack Password: ")
		rc_vars = commands.getoutput("cat %s | egrep -v '#|^$|echo|read|OS_PASSWORD'" % rc_file)
		env_params = rc_vars.split('\n')
		env_params.append("export OS_PASSWORD=%s" % os_password )
		#print env_params
		# export env values
		for p in env_params :
			pstring = p.strip('export ')
			key_val = pstring.split("=")
			key = key_val[0]
			val1 = key_val[1]
			val = val1.strip('"')
			#print "%s : %s" % (key,val) 
			os.environ[key] = val
		#print commands.getoutput("env | grep OS_")	
		# test env setting are ok
		print "Testing openstack environment setting ... "
		status,output = commands.getstatusoutput("nova list")
		#print "status:",status
		#print "output:",output 
		if status != 0 :
			print "Openstack CLI environment setting not correct"
			print output
			sys.exit(251)
		else :
			print "\nEnvironment settings look ok ! proceeding ..."		
	else :
		print "%s : No such file" % rc_file
		sys.exit(251)
def getAttributes() :
	print ("\n1. Select flavor for FIO controller (Large flavors recommended) "
		"\nHere are the available falvors in this environment : \n")
	flavor_list = commands.getoutput("nova flavor-list")
	print flavor_list
	flavor_id = raw_input("\nEnter the ID of the flavor : ")
	os.system('clear')
	print ("\n2. Select the network for the public IP of the FIO controller."
		"\nThis is the IP that will be used to access the FIO controller remotely.")
	pub_network_list = commands.getoutput("neutron --insecure net-list ")
	print pub_network_list
	pub_network_id = raw_input("\nEnter the ID of the public network : ")
	os.system('clear')
	print ("\n3. Now select the network for the private IP of the FIO controller."
		"\nThis is the network where all of the FIO drivers will be planted on.\n")
	pri_network_list = commands.getoutput("neutron --insecure net-list")
	print pri_network_list
	pri_network_id = raw_input("\nEnter the ID of the private network : ")
	os.system('clear')
	print ("4. Choose your image of preference for both the FIO controller and drivers\n")
	image_list = commands.getoutput("glance image-list")
	print image_list
	image_id = raw_input("\nEnter the ID of image chosen : ")
	print ("5. Additional cloud-init data"
		"\nThe cloud-init file for the controller must have ssh public key of the user "
		"that will be accessing the controller remotely")
        cloud_init_file = raw_input("\nEnter cloud-init file : " )
	os.system('clear')
	if os.path.isfile(cloud_init_file) :
		pass
	else :
		print "No such file : %s" % cloud_init_file
		print "aborting ..."
		sys.exit(251)

	instance_data = ([flavor_id,flavor_list],[pub_network_id,pub_network_list],[pri_network_id,pri_network_list],[image_id,image_list])
	
	for x in instance_data :
		if x[0] not in x[1]:
			print "Invalid ID : %s , ERROR" % x[0]
			sys.exit(251)
	instance_data = {"flavor_id" : flavor_id,"pub_net":pub_network_id,"pri_net":pri_network_id,"image_id":image_id,"cloud_init":cloud_init_file}
	
	return instance_data

def bootController(instance_data) :
	#nova boot --flavor 7d3f9041-fbd1-401f-8040-2ebfc78004e7 --nic net-id=43be8872-eafc-40cc-a968-9bf9a9698d34 --nic net-id=57a0d946-216c-4348-a869-101408266b85  --image 65069ec3-20cc-42e4-84fa-cd449c9a843f  --user-data user-data.txt alem-fio-master
	flavor_id = instance_data['flavor_id']
	net_id_pub = instance_data['pub_net']
	net_id_pri = instance_data['pri_net']
	image_id = instance_data['image_id']
	cloud_init = instance_data['cloud_init']
	boot_command = 'nova boot --flavor %s --nic net-id=%s --nic net-id=%s --image %s --user-data %s fio-controller-vm' % (flavor_id,net_id_pub,net_id_pri,image_id,cloud_init)
	print commands.getoutput(boot_command)
if __name__ == "__main__" :
	
	setEnvironment()
	launch_data = getAttributes()
	bootController(launch_data)
