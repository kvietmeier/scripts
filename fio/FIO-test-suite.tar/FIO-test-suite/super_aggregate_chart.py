#!/bin/python
import os,sys,string
import ConfigParser
import commands
from optparse import OptionParser
import subprocess
import re
import time
import matplotlib as mpl
mpl.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.backends.backend_pdf import PdfPages
from pylab import *
from snake_parse import loadConf
from snake_parse import fioTimeSeries

date_string = time.strftime("%d_%m_%Y")

def options_usage() :
        parser = OptionParser(usage="\n%prog -c <conf file> -d <comma separated list of metrics>",version="%prog 1.0")
        parser.add_option("-c","--config-file",dest="conf_file",help="Config file -- INI style configuration file used for FIO execution.")
	parser.add_option("-ld","--left-data",dest="leftdata",help="left Y-axis data -- for generating charts, below are the possible data names.")
	parser.add_option("-rd","--right-data",dest="rightdata",help="right Y-axis data -- for generating charts, here are the possible data names:\n"
			  "trbw = total read BW, \n"
			  "triops = total read IOps, \n"
			  "arlat = average read latency in ms, \n"
			  "twbw = total write BW\, n"
			  "twiops = total write IOps, \n"
			  "awlat = average write latency in ms, \n"
			  "arbw = average read BW\, n"
			  "ariops = average read IOPs, \n"
			  "awbw = average write BW, \n"
			  "awiops = average write IOps, \n")
        (options,args) = parser.parse_args()
        result = options
        return result

def snakeChart() :
	# units dictionary
	units_dict = {"trbw" : "Read BW(KB/s)", "triops" : "Read IOps" , "arlat" : "Average Read Lat(ms)", "twbw":"Write BW(KB/s)", "twiops" : "Write IOps", "awlat":"Average Write Lat(ms)", "arbw" : "Average Read BW(KB/s)", "ariops":"Average Read IOps", "awbw":"Average Write BW(KB/s)", "awiops":"Average Write IOps"}
	user_input = options_usage()
        conf_file = user_input.conf_file
	data = user_input.data
	if data :
        	metrics = data.split(",")
	else :
		print ("You need to provide comma separated list of metrics for charting\n"
		      "These are the possible values available :\n"
		      "trbw = total read BW, \n"
                      "triops = total read IOps, \n"
                      "arlat = average read latency in ms, \n"
                      "twbw = total write BW, \n"
                      "twiops = total write IOps, \n"
                      "awlat = average write latency in ms, \n"
                      "arbw = average read BW, \n"
                      "ariops = average read IOPs, \n"
                      "awbw = average write BW, \n"
                      "awiops = average write IOps, \n")
		sys.exit(251)

	for x in metrics :
		if x not in units_dict.keys() :
			print "%s - is NOT a valid metrics name\n" % x
			print "Run ./snake_chart.py --help to see the complete list\n"
			sys.exit(251)
	number_of_graphs = 0
	aggregate_data = []
	graph_data = []
        if conf_file and os.path.exists(conf_file) :
                project,fio_launch_data = loadConf(conf_file)
                chart_input = fioTimeSeries(project,fio_launch_data)
		flavor_list = fio_launch_data.keys()
		for flavor in flavor_list :
			conf = fio_launch_data[flavor] 
			# charting per  (flavor,depth,ratio,block_size) combo
			depth = conf["depth"]
			ratio = conf["rw_mix"]
			block_size = conf["blk_size"]
			for d in depth :
				for r in ratio :
					for bs in block_size :
						for m in metrics :
							# the above list makes up a chart name	
							chart_name = "%s-%s-%s-%s : %s" % (flavor,d,r,bs,m)
							# get chart data 
							x_axis = []
							y_axis = []
							for data in chart_input :
								 if ( data["flavor"] == flavor and data["depth"] == d and data["ratio"] == r and data["block_size"] == bs) :
									x_axis.append(data["run"])
									y_axis.append(data[m])
							#print x_axis
							#print y_axis
							y_label = units_dict[m]
							x_label = "run"
							number_of_graphs += 1
							graph_data.append({"chart_name":chart_name,"y_label":y_label,"x_label":x_label,"y_data":y_axis,"x_data":x_axis})
							aggregate_data.append({"flavor" : flavor,"depth": d, "ratio" : r,"block_size" : bs, "chart_data" : {"metrics":m,"y_label":y_label,"x_label":x_label,"y_data":y_axis,"x_data":x_axis}})
	return aggregate_data


def aggregatePlotter(metrics,conf_file) :
	print "Plotting chart ...\n"
	# units dictionary
        units_dict = {"trbw" : "Read BW(KB/s)", "triops" : "Read IOps" , "arlat" : "Average Read Lat(ms)", "twbw":"Write BW(KB/s)", "twiops" : "Write IOps", "awlat":"Average Write Lat(ms)", "arbw" : "Average Read BW(KB/s)", "ariops":"Average Read IOps", "awbw":"Average Write BW(KB/s)", "awiops":"Average Write IOps"}
	input_data = snakeChart()
	s_flavors = set()
	s_depth = set()
	s_ratio = set()
	s_block_size = set()
	for data in input_data :
		s_flavors.add(data["flavor"])		
		s_depth.add(data["depth"])
		s_ratio.add(data["ratio"])
		s_block_size.add(data["block_size"])
	# Aggregating data based on a specific metrics
	flavors = list(s_flavors)
	depth = list(s_depth)
	ratio = list(s_ratio)
	block_size = list(s_block_size)
	aggregate_input = []
	for bs in block_size :
		for r in ratio :
			for d in depth :
				plotter_input = []
				for flavor in flavors :
					for info in input_data :	
						if ( info["flavor"] == flavor and info["depth"] == d and info["ratio"] == r and info["block_size"] == bs and metrics in info["chart_data"].values() )  :
							aggregate_input.append( {"flavor" : flavor,"depth": d, "ratio" : r,"block_size" : bs, "chart_data" : info["chart_data"] }) 	
	#color scheme - not used
	color_spectrum = {"1":"g","2":"y","3":"r","4":"b","5":"c","6":"m","7":"k"}
	color_index = 1
	chart_list = []
	stack_count = 0
	for md in aggregate_input :
		chart_data = md['chart_data']
		x_data = chart_data['x_data']
		num_data_point = len(x_data)
		y_data = chart_data['y_data']
		total_ydata = 0 
		for y in y_data :
			total_ydata += y
		average_ydata = total_ydata / num_data_point
		label = "Aggregate data for average %s, block size : %s , IO : %s , Depth : %s, number of FIO runs : %s" % (metrics,md['block_size'],md['ratio'],md['depth'],num_data_point)
		y_label = chart_data['y_label']
		x_label = chart_data['x_label']
		color = color_spectrum[str(color_index)]
		color_index += 1
		chart_list.append({"total_y_data":[total_ydata],'average_y_data':[average_ydata],"color":color,"x_label":x_label,"y_label":y_label,"label":label,"flavor":md['flavor']})
		stack_count += 1
	
	index = np.arange(1)
	bar_width = 0.1
	opacity = 0.4
	error_config = {'ecolor': '0.3'}
	# start plotting
	multi_figure = plt.figure(1)
	# setting font size
        title_font = {'fontname':'Arial', 'size':'24', 'color':'black', 'weight':'normal','verticalalignment':'bottom'} # Bottom vertical alignment for more space
        axis_font = {'fontname':'Arial', 'size':'20'}
	# add each chart
	count = 0
	for xx in chart_list :	
		#plt.plot(xx["yerr"],xx["y_data"],label=xx["label"],linewidth=3.0)
		shift = count * bar_width
		plt.bar((index + shift), xx['average_y_data'], bar_width,alpha=opacity,color=xx['color'],yerr=[0],error_kw=error_config,label=xx['flavor'])
		plt.xlabel('Flavors')
		plt.ylabel(xx['y_label'])
		plt.title(xx['label'], **title_font)
		count += 1
	plt.xticks( index + bar_width,("flavors"))
	plt.legend()
	#plt.tight_layout()
	#labelling chart
	#plt.xlabel('Runs',**axis_font)
	#plt.ylabel(units_dict[metrics],**axis_font)
	#plt.title('Aggregate %s chart' % metrics, **title_font )
	multi_figure.set_size_inches(35,15)
	# output filename
	date_string = time.strftime("%d%m%Y")
	output_filename = "%s_%s_average_aggregate_%s_chart.pdf" % (date_string,conf_file.strip(".conf"),metrics)
	pp = PdfPages(output_filename)
	plt.savefig(pp, format='pdf')
	pp.close()
	print "Output file : %s \n" % output_filename









if __name__ == "__main__" :
	#snakeChart()
	user_input = options_usage()
        conf_file = user_input.conf_file
        metrics = user_input.data
	aggregatePlotter(metrics,conf_file)


