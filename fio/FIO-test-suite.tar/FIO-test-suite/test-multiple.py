#!/bin/python

import matplotlib as mpl
mpl.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.backends.backend_pdf import PdfPages
from pylab import *

t = arange(0.0, 2.0, 0.01)
s1 = sin(2*pi*t)
s2 = cos(4*pi*t)


fig = plt.figure()
ax1 = fig.add_subplot(121)
ax2 = fig.add_subplot(122)

ax1.loglog(t, s1)
ax2.loglog(t, s2)

ax1.set_xlabel('depth')
ax2.set_xlabel('runs')
ax1.set_ylabel('iops')
ax2.set_ylabel('latency')

ax1.set_title('average')
ax2.set_title('total')

fig.set_size_inches(20.5,5.5)
#savefig('fig1')

#pp = PdfPages('foo.pdf')
plt.savefig("labeled.pdf")
#save it in png and svg formats

