#!/bin/python
import os,sys,string
import ConfigParser
import commands
from optparse import OptionParser
import subprocess
import re
import time
import matplotlib as mpl
mpl.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.backends.backend_pdf import PdfPages
from pylab import *
from snake_parse import loadConf
from snake_parse import fioTimeSeries
from prettytable import PrettyTable

date_string = time.strftime("%d_%m_%Y")

def options_usage() :
        parser = OptionParser(usage="\n%prog -c <conf file> -l <left Y-axis data> -r <right Y-axis data>" ,version="%prog 1.0")
        parser.add_option("-c","--config-file",dest="conf_file",help="Config file -- INI style configuration file used for FIO execution.")
	parser.add_option("-l","--left-data",dest="leftdata",help="left Y-axis data -- for generating charts, below are the possible data names.")
	parser.add_option("-r","--right-data",dest="rightdata",help="right Y-axis data -- for generating charts, here are the possible data names:\n"
			  "trbw = total read BW, \n"
			  "triops = total read IOps, \n"
			  "arlat = average read latency in ms, \n"
			  "twbw = total write BW, \n"
			  "twiops = total write IOps, \n"
			  "awlat = average write latency in ms, \n"
			  "arbw = average read BW, \n"
			  "ariops = average read IOPs, \n"
			  "awbw = average write BW, \n"
			  "awiops = average write IOps, \n")
        (options,args) = parser.parse_args()
        result = options
        return result

def snakeChart(alpha,beta) :
        metrics = alpha.split(",")
	rmetrics = beta.split(",")
	number_of_graphs = 0
	rnumber_of_graphs = 0
        raggregate_data = []
	aggregate_data = []
	graph_data = []
        rgraph_data = []
	units_dict = {"trbw" : "Read BW(KB/s)", "triops" : "Read IOps" , "arlat" : "Average Read Lat(ms)", "twbw":"Write BW(KB/s)", "twiops" : "Write IOps", "awlat":"Average Write Lat(ms)", "arbw" : "Average Read BW(KB/s)", "ariops":"Average Read IOps", "awbw":"Average Write BW(KB/s)", "awiops":"Average Write IOps"}
        if conf_file and os.path.exists(conf_file) :
                project,fio_launch_data = loadConf(conf_file)
                chart_input = fioTimeSeries(project,fio_launch_data)
		flavor_list = fio_launch_data.keys()
		for flavor in flavor_list :
			conf = fio_launch_data[flavor] 
			# charting per  (flavor,depth,ratio,block_size) combo
			depth = conf["depth"]
			ratio = conf["rw_mix"]
			block_size = conf["blk_size"]
			rwmixread = conf["rwmixread"]
			for d in depth :
				for r in ratio :
					for bs in block_size :
						for m in metrics :
							# the above list makes up a chart name	
							chart_name = "%s-%s-%s-%s : %s" % (flavor,d,r,bs,m)
							# get chart data 
							x_axis = []
							y_axis = []
							for data in chart_input :
								 if ( data["flavor"] == flavor and data["depth"] == d and data["ratio"] == r and data["block_size"] == bs) :
									x_axis.append(data["run"])
									y_axis.append(data[m])
							#print x_axis
							#print y_axis
							y_label = units_dict[m]
							x_label = "run"
							number_of_graphs += 1
							graph_data.append({"chart_name":chart_name,"y_label":y_label,"x_label":x_label,"y_data":y_axis,"x_data":x_axis})
							aggregate_data.append({"flavor" : flavor,"depth": d, "ratio" : r,"block_size" : bs, "chart_data" : {"metrics":m,"y_label":y_label,"x_label":x_label,"y_data":y_axis,"x_data":x_axis},"rwmixread" : rwmixread})

						for m in rmetrics :
                                                        # the above list makes up a chart name
                                                        chart_name = "%s-%s-%s-%s : %s" % (flavor,d,r,bs,m)
                                                        # get chart data
                                                        x_axis = []
                                                        y_axis = []
                                                        for data in chart_input :
                                                                 if ( data["flavor"] == flavor and data["depth"] == d and data["ratio"] == r and data["block_size"] == bs) :
                                                                        x_axis.append(data["run"])
                                                                        y_axis.append(data[m])
                                                        #print x_axis
                                                        #print y_axis
                                                        y_label = units_dict[m]
                                                        x_label = "run"
                                                        number_of_graphs += 1
                                                        rgraph_data.append({"chart_name":chart_name,"y_label":y_label,"x_label":x_label,"y_data":y_axis,"x_data":x_axis})
                                                        raggregate_data.append({"flavor" : flavor,"depth": d, "ratio" : r,"block_size" : bs, "chart_data" : {"metrics":m,"y_label":y_label,"x_label":x_label,"y_data":y_axis,"x_data":x_axis}})	


	return (aggregate_data,raggregate_data)


def aggregatePlotter(conf_file) :
 column = 1
 figure_id = 1
 super_data = {'ariops':'arlat','awiops':'awlat'}
 multi_figure = plt.figure()
 #multi_figure.add_axes((.1,.4,.8,.5))

 footer_data = {"small":[],"medium":[],"large":[],"xlarge":[]}
 for ud in super_data :
	metrics = ud
	rmetrics = super_data[ud]
	print "Plotting chart ...\n"
	# units dictionary
        units_dict = {"trbw" : "Read BW(KB/s)", "triops" : "Read IOps" , "arlat" : "Average Read Lat(ms)", "twbw":"Write BW(KB/s)", "twiops" : "Write IOps", "awlat":"Average Write Lat(ms)", "arbw" : "Average Read BW(KB/s)", "ariops":"Average Read IOps", "awbw":"Average Write BW(KB/s)", "awiops":"Average Write IOps"}
	input_data,rinput_data = snakeChart(metrics,rmetrics)
	s_flavors = set()
	s_depth = set()
	s_ratio = set()
	s_block_size = set()
	#rwmixread = input_data['rwmixread']
	for data in input_data :
		s_flavors.add(data["flavor"])		
		s_depth.add(data["depth"])
		s_ratio.add(data["ratio"])
		s_block_size.add(data["block_size"])
	# Aggregating data based on a specific metrics
	flavors = list(s_flavors)
	depth = list(s_depth)
	ratio = list(s_ratio)
	block_size = list(s_block_size)
	aggregate_input = []
	reference_flist = ["small","medium","large","xlarge"]
	ordered_flavors = []
	for f in reference_flist :
		if f in flavors :
			ordered_flavors.append(f)
	for bs in block_size :
		for r in ratio :
			for d in depth :
				plotter_input = []
				for flavor in ordered_flavors :
					for info in input_data :	
						if ( info["flavor"] == flavor and info["depth"] == d and info["ratio"] == r and info["block_size"] == bs and metrics in info["chart_data"].values() )  :
							aggregate_input.append( {"flavor" : flavor,"depth": d, "ratio" : r,"block_size" : bs, "chart_data" : info["chart_data"],"rwmixread" : info["rwmixread"] }) 	
	
	raggregate_input = []
        for bs in block_size :
                for r in ratio :
                        for d in depth :
                                plotter_input = []
                                for flavor in ordered_flavors :
                                        for info in rinput_data :
                                                if ( info["flavor"] == flavor and info["depth"] == d and info["ratio"] == r and info["block_size"] == bs and rmetrics in info["chart_data"].values() )  :
                                                        raggregate_input.append( {"flavor" : flavor,"depth": d, "ratio" : r,"block_size" : bs, "chart_data" : info["chart_data"] })
	#color scheme - not used
	color_spectrum = {"1":"g","2":"y","3":"r","4":"b","5":"c","6":"m","7":"k"}
	color_index = 1
	chart_list = []
	stack_count = 0
	for md in aggregate_input :
		chart_data = md['chart_data']
		x_data = chart_data['x_data']
		num_data_point = len(x_data)
		y_data = chart_data['y_data']
		total_ydata = 0 
		for y in y_data :
			total_ydata += y
		average_ydata = total_ydata / num_data_point
		label = "Aggregate data for %s [ block size : %s , IO : %s , Depth : %s, number of FIO runs : %s, rwmixread : %s%% ]" % (metrics,md['block_size'],md['ratio'],md['depth'],num_data_point,md['rwmixread'])
		y_label = chart_data['y_label']
		x_label = chart_data['x_label']
		color = color_spectrum[str(color_index)]
		color_index += 1
		chart_list.append({"total_y_data":[total_ydata],'average_y_data':[average_ydata],"color":color,"x_label":x_label,"y_label":y_label,"label":label,"flavor":md['flavor']})
		stack_count += 1
	
	rchart_list = []
        rstack_count = 0
        for md in raggregate_input :
                chart_data = md['chart_data']
                x_data = chart_data['x_data']
                num_data_point = len(x_data)
                y_data = chart_data['y_data']
                total_ydata = 0.0
                for y in y_data :
                        total_ydata += y
                average_ydata = total_ydata / num_data_point
                #label = "Aggregate data for average %s, block size : %s , IO : %s , Depth : %s, number of FIO runs : %s" % (metrics,md['block_size'],md['ratio'],md['depth'],num_data_point)
                y_label = chart_data['y_label']
                x_label = chart_data['x_label']
                #color = color_spectrum[str(color_index)]
                #color_index += 1
                rchart_list.append({"total_y_data":[total_ydata],'average_y_data':[average_ydata],"flavor":md['flavor'],"y_label":y_label})
                stack_count += 1

	
	index = np.arange(1)
	bar_width = 0.25
	opacity = 0.4
	error_config = {'ecolor': '0.3'}
	#ax = multi_figure.add_subplot(111)
	# setting font size
        title_font = {'fontname':'Arial', 'size':'24', 'color':'black', 'weight':'normal','verticalalignment':'bottom'} # Bottom vertical alignment for more space
        axis_font = {'fontname':'Arial', 'size':'24'}
	# add each chart
	count = 0
	left_x = []
	for xx in chart_list :	
		#plt.plot(xx["yerr"],xx["y_data"],label=xx["label"],linewidth=3.0)
		draw = multi_figure.add_subplot(3,1,figure_id)
		shift = count * bar_width 
		#if count != 0 :
		#	shift += (bar_width*count)
		draw.bar((index + shift), xx['average_y_data'], bar_width,alpha=opacity,color=xx['color'],yerr=[0],error_kw=error_config,label=xx['flavor'])
		draw.annotate('%s' % xx['average_y_data'][0], xy=(index + shift,xx['average_y_data'][0]), xytext=(150,5), textcoords='offset points')
		draw.set_xlabel('Flavors',**axis_font)
		draw.set_ylabel(xx['y_label'],**axis_font)
		draw.set_title(xx['label'], **title_font)
		left_x.append( 0.05 + index + shift)
		count += 1
		footer_data[xx['flavor']].append({xx['y_label']:xx['average_y_data'][0]}) 


	#draw.xticks( index + bar_width,("flavors"))
	draw.legend()

	left_y = []
	left_ticks = []
	for xx in rchart_list :
		left_y.append(xx['average_y_data'])
		left_y_label = xx['y_label']
		left_ticks.append(xx['flavor'])
		footer_data[xx['flavor']].append({xx['y_label']:xx['average_y_data'][0]})
	left_plt = draw.twinx()
	#print left_y
	left_plt.plot(left_x,left_y,linewidth=4,color='g')
	for i,j in zip(left_x,left_y) :
		left_plt.annotate('%s' %j[0], xy=(i[0],j[0]), xytext=(10,0), textcoords='offset points')
    		#plt.annotate('(%s,' %i[0], xy=(i[0],j[0]))

        left_plt.set_ylabel(left_y_label,**axis_font)	
        #plt.xlabel(left_x_label)	
	plt.xticks(left_x, left_ticks)	
	plt.tick_params(axis='x', labelsize=24)

	#plt.tight_layout()
	#labelling chart
	#plt.xlabel('Runs',**axis_font)
	#plt.ylabel(units_dict[metrics],**axis_font)
	#plt.title('Aggregate %s chart' % metrics, **title_font )
	#multi_figure.set_size_inches(35,25)
	# output filename
	figure_id += 1
 multi_figure.set_size_inches(35,25)
 #multi_figure.add_axes((.1,.4,.8,.5))
 footer = PrettyTable(["Flavor/Type","Average Write IOps","Write Lat(ms)","Average Read IOps","Read Lat(ms)"])
 footer.padding_width = 1
 #footer.add_row([])
 #print footer_data	

 # 'small': [{'Write IOps': 17190.933333333334}, {'Average Write Lat(ms)': 6.91300430561555}, {'Read IOps': 68381.11666666667}, {'Average Read Lat(ms)': 155.67283743196555}]
 col_labels = ["Average Read IOps","Read Lat(ms)","Average Write IOps","Write Lat(ms)"]
 row_labels = []
 vals = []
 twiops = 0.0
 twlat = 0.0
 triops = 0.0
 trlat = 0.0
 ordered_falvors = ["small","medium","large","xlarge"]
 for f in ordered_falvors :
	twiops += footer_data[f][0].values()[0]
	twlat += footer_data[f][1].values()[0]
	triops += footer_data[f][2].values()[0]
	trlat += footer_data[f][3].values()[0]
	row_labels.append(f)
	footer.add_row([f,footer_data[f][0].values()[0],footer_data[f][1].values()[0],footer_data[f][2].values()[0],footer_data[f][3].values()[0]])	
	vals.append([footer_data[f][0].values()[0],footer_data[f][1].values()[0],footer_data[f][2].values()[0],footer_data[f][3].values()[0]])
 #draw = multi_figure.add_subplot(2,2,3)
 row_labels.append("Cluster Total")
 vals.append([twiops,twlat/4,triops,trlat/4])
 the_table = plt.table(cellText=vals,colWidths = [0.1]*10,rowLabels=row_labels,colLabels=col_labels,loc='bottom')
 the_table.scale(2.0, 4)
 the_table.set_fontsize(24)
 print footer
 #multi_figure.text(0.3,0.3,footer,fontsize=28)	
 date_string = time.strftime("%d%m%Y")
 output_filename = "%s_%s_aggregate_chart.pdf" % (date_string,conf_file.strip(".conf"))
 pp = PdfPages(output_filename)
 plt.savefig(pp, format='pdf')
 pp.close()
 print "Output file : %s \n" % output_filename









if __name__ == "__main__" :
	#snakeChart()
	user_input = options_usage()
        conf_file = user_input.conf_file
        #metrics = user_input.leftdata
	#rmetrics = user_input.rightdata
	aggregatePlotter(conf_file)


