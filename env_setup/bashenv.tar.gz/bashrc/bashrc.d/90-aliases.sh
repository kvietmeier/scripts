###############################################################################
### Bash Aliases and Productivity Helpers
### File: .bashrc.d/05-aliases.sh
### Created by Karl Vietmeier
### Purpose: Desktop alerts, VoC shortcuts, Terraform helpers, and Linux CLI aliases
###############################################################################

###--- Alert Notifications
# Send a desktop notification when a long-running command finishes
alias alert='notify-send --urgency=low -i "$([ $? = 0 ] && echo terminal || echo error)" \
  "$(history | tail -n1 | sed -e '\''s/^\s*[0-9]\+\s*//;s/[;&|]\s*alert$//'\'')"'

###--- VAST on Cloud (VoC) Aliases
alias install-vast01="${HOME}/bin/vast.voc.install.py"         # Run VoC installer wrapper
alias pgpsecrets="${HOME}/Terraform/scripts/extracts3secret.sh" # Extract secrets from S3
alias vmsstat="${HOME}/bin/vms.status.py"                       # VMS status script

###--- Base Terraform directory for VoC
# Use environment variable TFDIR if set, otherwise fallback to default
: "${TFDIR:=$HOME/Terraform/vast_on_cloud/5_3/1861115-h5-beta1}"

# Quick CD into VoC Terraform directories
alias vocdir="cd ${HOME}/Terraform/vast_on_cloud/5_3"
alias cluster01="cd ${TFDIR}/cluster01"
alias cluster02="cd ${TFDIR}/cluster02"
alias cluster03="cd ${TFDIR}/cluster03"

###--- Terraform Output Helpers
# NOTE: Must be run from a Terraform directory with state
alias vms='terraform output -raw cluster_mgmt'
alias vmsmon='terraform output -raw vms_monitor'
alias vmsip='terraform output -raw vms_ip'

###--- Linux CLI Productivity Aliases
# Smarter 'ls' commands
alias l="ls -CFv"
alias la="ls -Av"
alias ls="ls -hF --color=auto"
alias ll='ls -lhvF --group-directories-first'
alias lla='ls -alhvF --group-directories-first'

# Grep with colors
alias egrep='egrep --color=auto'
alias fgrep='fgrep --color=auto'
alias grep='grep --color=auto'

# Quick directory navigation
alias cdb='cd -'         # Go back
alias up='cd ..'         # Up 1 dir
alias up2='cd ../..'     # Up 2 dirs
alias up3='cd ../../..'  # Up 3 dirs

# Disk usage
alias df='df -kh'
alias du='du -h'

# Shortcut to VAST Terraform root (optional, override with environment variable)
: "${VASTTF_ROOT:=$HOME/Terraform/vastdata}"
alias vasttf="cd ${VASTTF_ROOT}"

###--- Include User Aliases (if defined)
[ -f "${HOME}/.bash_aliases" ] && . "${HOME}/.bash_aliases"
