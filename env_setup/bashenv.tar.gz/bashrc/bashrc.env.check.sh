#!/bin/bash
###############################################################################
### Check required dependencies for .bashrc.d environment
### Created by Karl Vietmeier
### Works on Ubuntu and CentOS
###############################################################################

echo "Checking required commands and dependencies..."

# List of required commands
required_cmds=(
    bash
    terraform
    aws
    gcloud
    jq
    python3
    ls
    grep
    df
    du
    notify-send
)

# Function to check each command
for cmd in "${required_cmds[@]}"; do
    if ! command -v "$cmd" >/dev/null 2>&1; then
        echo "WARNING: $cmd is not installed or not in PATH."
    else
        echo "OK: $cmd found."
    fi
done

# Check for ~/.bashrc.d existence
if [ ! -d "$HOME/.bashrc.d" ]; then
    echo "INFO: $HOME/.bashrc.d directory does not exist. You may want to create it."
fi

# Optional: Check for Python scripts if they exist
#python_scripts=(
#    "$HOME/bin/vast.voc.install.py"
#    "$HOME/bin/vms.status.py"
#    "$HOME/Terraform/scripts/extracts3secret.sh"
#)
#
#for script in "${python_scripts[@]}"; do
#    if [ ! -f "$script" ]; then
#        echo "INFO: Python script or shell helper not found: $script"
#    else
#        echo "OK: Found $script"
#    fi
#done

echo "Dependency check complete."
