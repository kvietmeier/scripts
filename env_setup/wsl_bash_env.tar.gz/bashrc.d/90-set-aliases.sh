###############################################################################
### Bash Aliases and Productivity Helpers
### File: .bashrc.d/05-aliases.sh
### Created by Karl Vietmeier
### Purpose: Desktop alerts, VoC shortcuts, Terraform helpers, and Linux CLI aliases
###############################################################################


###--- Alert Notifications
# Send a desktop notification when a long-running command finishes
alias alert='notify-send --urgency=low -i "$([ $? = 0 ] && echo terminal || echo error)" \
  "$(history | tail -n1 | sed -e '\''s/^\s*[0-9]\+\s*//;s/[;&|]\s*alert$//'\'')"'


###--- Linux CLI Productivity Aliases ---###
alias refresh=". ${HOME}/.bashrc"

# Smarter 'ls' commands
alias l="ls -CFv"
alias la="ls -Av"
alias ls="ls -hF --color=auto"
alias ll='ls -lhvF --group-directories-first'
alias lla='ls -alhvF --group-directories-first'

# Grep with colors
alias egrep='egrep --color=auto'
alias fgrep='fgrep --color=auto'
alias grep='grep --color=auto'

# Quick directory navigation
alias cdb='cd -'         # Go back
alias up='cd ..'         # Up 1 dir
alias up2='cd ../..'     # Up 2 dirs
alias up3='cd ../../..'  # Up 3 dirs

# Disk usage
alias df='df -kh'
alias du='du -h'

# Shortcut to VAST Terraform root (optional, override with environment variable)
alias vasttf="cd ${VASTTF_ROOT}"

###--- VAST on Cloud (VoC) Aliases (not setup yet)
alias install_vast01="${HOME}/bin/vast.voc.install.py"         # Run VoC installer wrapper
alias pgpsecrets="${HOME}/Terraform/scripts/vast.extracts3secret.sh" # Extract secrets from S3
alias vmsstat="${HOME}/bin/vms.status.py"                       # VMS status script

# Quick CD into VoC Terraform directories
alias vocdir="cd ${TFDIR}/vast_on_cloud/5_3"
alias vastdir="cd ${VASTTF_ROOT}"
alias cluster01="cd ${VASTGCP}/cluster01"
alias cluster02="cd ${VASTGCP}/cluster02"
alias cluster03="cd ${VASTGCP}/cluster03"

###--- Terraform Output Helpers
# NOTE: Must be run from a Terraform directory with state
alias vms='terraform output -raw cluster_mgmt'
alias vmsmon='terraform output -raw vms_monitor'
alias vmsip='terraform output -raw vms_ip'

###--- GCP Helper Aliases for functions in .bashrc.d/81-functions-gcp.sh
alias gcpinstances=GCPListInstances
alias gcpsubnets=GCPListSubnets
alias gcporphanroutes=GCPGetOrphanedRoutesCore
alias gcporphan=GCPGetOrphanedRoutes
alias gcptoken=GCPGetAccessToken
alias gcpuser=GCPGetCoreAcct
alias gcproj=GCPGetProject
alias gcloud="$GCLOUD_CMD"


###--- Azure Helper Aliases for functions in .bashrc.d/83-functions-azure.sh
alias azdisks=list_azdisks
alias azvms=list_azvms
alias azsubnets=list_azsubnets
alias azvnets=list_azvnets
alias azlogin=azlogin
alias azlogout=azlogout
alias azshow=azshow
alias azcontext=azcontext

###--- AWS Helper Aliases for functions in .bashrc.d/82-functions-aws.sh
alias awslogin=aws_sso_login
alias awscheck=aws_check_all_profiles
alias awslist=aws_list_profiles
alias awsversion=aws_cli_version
alias awslogout=aws_sso_logout


###--- Include User Aliases (if defined)
[ -f "${HOME}/.bash_aliases" ] && . "${HOME}/.bash_aliases"