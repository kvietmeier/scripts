###============================================================###
###   Setup Environment Variables
###   File: .bashrc.d/00-set-env_variables.sh
###   Created by Karl Vietmeier
###   Purpose: Sets PATH, general environment variables, and
###            sources personal environment variables
###============================================================###

###--- Add local bin directories to PATH
case ":$PATH:" in
  *":$HOME/.local/bin:$HOME/bin:"*) ;;
  *) PATH="$HOME/.local/bin:$HOME/bin:$PATH" ;;
esac
export PATH



###--- General environment variables
export EDITOR=vim
export VISUAL=vim

###============================================================###
###---            Localized Environment Variables           ---###
###============================================================###

###--- Base Terraform directory
export TFDIR="${HOME}/Terraform"

###--- VAST Terraform root directories
export VASTTF="${TFDIR}/vastdata"
export VOCDIR="${TFDIR}/vast_on_cloud"

###--- Terraform cloud provider directories
export TFGCP="${TFDIR}/gcp/"
export TFAWS="${TFDIR}/aws/"
export TFAZ="${TFDIR}/azure/"

###--- Google Cloud SDK Configuration
# Use native Linux gcloud only
export GCLOUD_CMD="/usr/bin/gcloud"


# --- WSL-specific settings ---
if grep -qi microsoft /proc/version 2>/dev/null; then
    # Remove old Windows gcloud / sync paths
    for win_path in \
        "/mnt/c/Users/karl.vietmeier/AppData/Local/Google/Cloud SDK/google-cloud-sdk/bin" \
        "/mnt/c/Program Files (x86)/Google/Cloud SDK/google-cloud-sdk/bin" \
        "/mnt/c/Program Files/Google/Google Apps Sync/"; do
        PATH=$(echo "$PATH" | tr ':' '\n' | grep -vF "$win_path" | tr '\n' ':' | sed 's/:$//')
    done

    export PATH

    # Browser Fix for WSLg
    if command -v wslview >/dev/null 2>&1; then
        export BROWSER=wslview
    fi
fi


###############################################################################
# Include Personal Environment Variables (if defined)
# ~/.bash_environment is intended for user-specific and potentially sensitive
# environment variables. Keep this file secure (chmod 600).
###############################################################################
[ -f "${HOME}/.bash_environment" ] && . "${HOME}/.bash_environment"

###--- End of File ---###