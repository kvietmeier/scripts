# Shell options
shopt -s checkwinsize    # Auto-resize window
set -o vi                # vi-style command line editing
bind 'set bell-style none'
