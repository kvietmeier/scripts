# VAST environment variables
export VMS_USER=admin
export VMS_PASSWORD=123456
export VMS_ADDRESS=vms
# export VMS_TOKEN=token
# export VMS_TENANT_NAME=tenant-name
# export VMS_API_VERSION=api-version
