# History configuration
export HISTSIZE=10000
export HISTFILESIZE=20000
export HISTCONTROL=ignoredups:erasedups
export HISTIGNORE="ls:bg:fg:history"
export HISTFILE=~/.bash_history

# Append to the history file, don’t overwrite it
shopt -s histappend

# Write and read new history lines without clearing (fixes !###)
PROMPT_COMMAND="history -a; history -n; $PROMPT_COMMAND"
