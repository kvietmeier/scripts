# Load custom functions (moved from ~/bin/bashfunctions.sh)
[ -f "$HOME/.bashrc.d/bashfunctions.sh" ] && . "$HOME/.bashrc.d/bashfunctions.sh"
