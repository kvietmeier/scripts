###############################################################################
### GCP Authentication and Utilities
### File: .bashrc.d/03-gcp.sh
### Created by Karl Vietmeier
### Purpose: Simplify GCP service account authentication and deauthentication
###############################################################################

###--- Authenticate to GCP using service account credentials
gcp_auth() {
    # Validate environment variables and credentials file
    {
        [ -n "$GOOGLE_APPLICATION_CREDENTIALS" ] && [ -f "$GOOGLE_APPLICATION_CREDENTIALS" ] || {
            echo "Missing or invalid credentials file: \$GOOGLE_APPLICATION_CREDENTIALS is not set or file does not exist"
            return 1
        }

        [ -n "$GCP_DEFAULT_PROJECT" ] || {
            echo "Missing GCP project ID. Set GCP_DEFAULT_PROJECT environment variable."
            return 1
        }
    }

    echo "Using credentials file: $GOOGLE_APPLICATION_CREDENTIALS"

    # Activate service account and set project
    gcloud auth activate-service-account --key-file="$GOOGLE_APPLICATION_CREDENTIALS" > /dev/null 2>&1 || {
        echo "Failed to activate service account."
        return 1
    }

    gcloud config set project "$GCP_DEFAULT_PROJECT" > /dev/null 2>&1 || {
        echo "Failed to set GCP project: $GCP_DEFAULT_PROJECT"
        return 1
    }

    # Validate Application Default Credentials
    gcloud auth application-default print-access-token > /dev/null 2>&1 || {
        echo "Failed to retrieve access token."
        return 1
    }

    echo "Service account activated, project set, and ADC validated."
}

###--- Deauthenticate from GCP
gcp_deauth() {
    echo "Deauthenticating from GCP..."

    # Revoke application default credentials (local cache)
    gcloud auth application-default revoke --quiet > /dev/null 2>&1
    gcloud auth revoke --quiet > /dev/null 2>&1

    echo "GCP authentication cleared from local session."
}

###--- Check GCP Authentication Status
gcp_status() {
    echo "GCP Authentication Status:"         
    gcloud auth list --filter=status:ACTIVE --format="value(account)" || echo "No active account"
    echo "Current GCP Project:"
    gcloud config get-value project || echo "No project set"
}