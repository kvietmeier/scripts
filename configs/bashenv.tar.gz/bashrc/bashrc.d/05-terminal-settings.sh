###############################################################################
### Terminal, History, and Prompt Configuration
### File: .bashrc.d/01-terminal.sh
### Created by Karl Vietmeier
### Purpose: Configure shell history, colors, aliases, terminal options, and prompt
###############################################################################

###--- History Configuration
export HISTSIZE=10000
export HISTFILESIZE=20000
export HISTCONTROL=ignoredups:erasedups
export HISTIGNORE="ls:bg:fg:history"
export HISTFILE=~/.bash_history

# Append to the history file, don’t overwrite it
shopt -s histappend

# Write and read new history lines without clearing (fixes !### behavior)
PROMPT_COMMAND="history -a; history -n; $PROMPT_COMMAND"

###--- Colors and Aliases
# Enable color support for ls/grep and define useful aliases
if [ -x /usr/bin/dircolors ]; then
    if [ -r ~/.dircolors ]; then
        eval "$(dircolors -b ~/.dircolors)"
    else
        eval "$(dircolors -b)"
    fi
    alias grep='grep --color=auto'
    alias fgrep='fgrep --color=auto'
    alias egrep='egrep --color=auto'
fi

###--- Terminal Options
shopt -s checkwinsize        # Auto-resize window
set -o vi                    # vi-style command line editing
bind 'set bell-style none'   # Disable terminal bell

###--- Prompt Configuration
# Set up a colored prompt if terminal supports it
case "$TERM" in
    xterm-color|*-256color) color_prompt=yes ;;
esac

if [ "$color_prompt" = yes ]; then
    PS1='\[\033[01;32m\]\u@\h\[\033[00m\]:\[\033[01;34m\]\w\[\033[00m\]\$ '
else
    PS1='\u@\h:\w\$ '
fi
unset color_prompt

# Terminal title for xterm/rxvt
case "$TERM" in
    xterm*|rxvt*)
        PS1="\[\e]0;\u@\h: \w\a\]$PS1"
        ;;
esac
export PS1    