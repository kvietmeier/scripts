###============================================================###
###   Setup Environment Variables
###   File: .bashrc.d/00-set-env_variables.sh
###   Created by Karl Vietmeier
###   Purpose: Sets PATH, general environment variables, and
###            sources personal environment variables
###============================================================###

###--- Add local bin directories to PATH
if ! [[ "$PATH" =~ "$HOME/.local/bin:$HOME/bin:" ]]; then
    PATH="$HOME/.local/bin:$HOME/bin:$PATH"
fi
export PATH

###--- AWS SSO Browser Fix for WSLg
# Ensure URLs open in Windows browser instead of Linux (gio)
# Requires: wslu package (`sudo apt-get install wslu -y`)
if command -v wslview >/dev/null 2>&1; then
    export BROWSER=wslview
fi

###--- General environment variables
export EDITOR=vim
export VISUAL=vim


###############################################################################
# Include Personal Environment Variables (if defined)
# ~/.bash_environment is intended for user-specific and potentially sensitive
# environment variables. Keep this file secure (chmod 600).
###############################################################################
[ -f "${HOME}/.bash_environment" ] && . "${HOME}/.bash_environment"
